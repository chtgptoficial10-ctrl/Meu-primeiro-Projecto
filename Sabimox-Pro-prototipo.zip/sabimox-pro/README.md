# Sabimox Pro — Protótipo web

Aplicação demonstrativa de gestão de rascunhos de faturação, com interface responsiva para telemóveis e computadores.

## Como utilizar

Abra `index.html` num navegador moderno. Não requer instalação de dependências.

## Funcionalidades

- Dados da empresa (nome, NIF e telefone)
- Cadastro de cliente em cada rascunho
- Itens, quantidades e preços em Kwanzas
- Totais automáticos
- Histórico de rascunhos
- Impressão / exportação PDF pelo navegador
- Armazenamento local no navegador (`localStorage`)

## Limitações importantes

Esta é uma **demonstração**, não um sistema de faturação fiscal certificado. Os documentos estão identificados como **rascunhos sem validade fiscal**. Os dados não são sincronizados entre dispositivos, não há login, nem base de dados online. Limpar os dados do navegador pode eliminar os registos. Não introduza dados reais sensíveis nesta versão de demonstração.

## Próximas etapas

Implementar autenticação, base de dados online, controlo de permissões, backups, catálogo de produtos, gestão de stock, impostos e validação dos requisitos fiscais aplicáveis em Angola antes de qualquer utilização oficial.
